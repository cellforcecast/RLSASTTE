import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np
import math
from math import sqrt
from utils.masking import TriangularCausalMask, ProbMask
import os
from models.STGC import stgc

class FullAttention(nn.Module):
    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super(FullAttention, self).__init__()
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def forward(self, queries, keys, values, attn_mask):
        B, L, H, E = queries.shape
        _, S, _, D = values.shape
        scale = self.scale or 1. / sqrt(E)

        scores = torch.einsum("blhe,bshe->bhls", queries, keys)

        if self.mask_flag:
            if attn_mask is None:
                attn_mask = TriangularCausalMask(B, L, device=queries.device)

            scores.masked_fill_(attn_mask.mask, -np.inf)

        A = self.dropout(torch.softmax(scale * scores, dim=-1))
        V = torch.einsum("bhls,bshd->blhd", A, values)

        if self.output_attention:
            return (V.contiguous(), A)
        else:
            return (V.contiguous(), None)

class AttentionLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads, d_keys=None, d_values=None, root_path='./data/ETT/', sid_10='SID_10.npy',
                 gpu=0, use_gpu=True, use_multi_gpu=False, devices= '0,1,2,3', c_in=1, c_out=1, dropout_stgc=0.001, target=17):
        super(AttentionLayer, self).__init__()

        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.inner_attention = attention

        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)

        self.n_heads = n_heads

        self.root_path = root_path
        self.sid_10 = sid_10

        self.gpu = gpu
        self.use_gpu = use_gpu
        self.use_multi_gpu = use_multi_gpu
        self.devices = devices

        self.device = self._acquire_device()

        self.stgc = stgc(c_in, c_out, dropout_stgc)
        self.target = target

        self.weight_auto_cross = nn.Parameter(torch.tensor([0.9]))
        self.weight_stgc = nn.Parameter(torch.tensor([0.1]))

    def forward(self, queries, keys, values, af_assist, attn_mask):
        pass
        return None, None

    def _acquire_device(self):
        if self.use_gpu:
            os.environ["CUDA_VISIBLE_DEVICES"] = str(
                self.gpu) if not self.use_multi_gpu else self.devices
            device = torch.device('cuda:{}'.format(self.gpu))
            #print('Use GPU: cuda:{}'.format(self.gpu))
        else:
            device = torch.device('cpu')
            #print('Use CPU')
        return device
