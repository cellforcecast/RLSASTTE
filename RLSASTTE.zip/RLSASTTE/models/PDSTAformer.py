import torch
import torch.nn as nn
from layers.Embed import DataEmbedding_wo_pos, DataEmbedding_wo_pos_fourdim
from layers.STAM import FullAttention, AttentionLayer
from layers.Trans_encoder import Encoder, EncoderLayer
from layers.Moedecomp import series_decomp_multi
from layers.Norm import mynorm

class stautoformer(nn.Module):

    def __init__(self, configs):
        super(stautoformer, self).__init__()
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len
        self.pred_len = configs.pred_len
        self.output_attention = configs.output_attention


        kernel_size = configs.moving_avg
        self.moedecomp = series_decomp_multi(kernel_size)

        self.projection_one = nn.Linear(configs.d_model, configs.c_out, bias=True)

        # Embedding
        self.enc_embedding = DataEmbedding_wo_pos(configs.enc_in, configs.d_model, configs.embed, configs.freq, configs.dropout)#self.enc_embedding和self.dec_embedding都是类对象。
        self.dec_embedding = DataEmbedding_wo_pos(configs.dec_in, configs.d_model, configs.embed, configs.freq, configs.dropout)
        self.enc_embedding_fourdim = DataEmbedding_wo_pos_fourdim(configs.enc_in, configs.d_model, configs.embed, configs.freq, configs.dropout)

        self.encoder = Encoder(
            [EncoderLayer(AttentionLayer(FullAttention(False, configs.factor, attention_dropout=configs.dropout,
                                                               output_attention=configs.output_attention),
                                               configs.d_model, configs.n_heads,
                                               root_path=configs.root_path, sid_10=configs.sid_10,
                                               gpu=configs.gpu, use_gpu=configs.use_gpu, use_multi_gpu=configs.use_multi_gpu, devices=configs.devices,
                                               c_in=configs.d_model, c_out=configs.d_model, dropout_stgc=configs.dropout, target=configs.target),
                          configs.d_model, configs.d_ff, dropout=configs.dropout,
                    activation=configs.activation) for l in range(configs.e_layers)], norm_layer=mynorm(configs.d_model) )
    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, af_assist, enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):

        pass


        if self.output_attention:
            return None
        else:
            return None
