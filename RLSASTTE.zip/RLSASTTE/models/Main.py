import numpy as np
import os
import torch
import torch.nn as nn
from models.PDSTAformer import stautoformer
from models.MSSTC import mgstc
from models.LSCDA import scgat
from layers.ADGM import adgfm
import torch.nn.functional as F

class model_total(nn.Module):
    def __init__(self, condition):
        super(model_total, self).__init__()
        self.condition = condition
        self.device = self._acquire_device()
        self.pred = condition.pred_len

        self.stautoformer = nn.ModuleList()
        self.mgstc = nn.ModuleList()
        self.scgat = nn.ModuleList()
        self.adgfm = nn.ModuleList()
        self.skip_convs = nn.ModuleList()
        self.projection= nn.Linear(condition.c_out, condition.c_out, bias=True)
        self.activation = F.relu


        for i in range(condition.blocks):
            self.stautoformer.append(stautoformer(condition))
            self.mgstc.append(mgstc(condition.in_dim_st, condition.out_dim_st))
            self.scgat.append(scgat(condition.in_dim_st, condition.out_dim_st))
            self.adgfm.append(adgfm(condition.out_dim_adgfm))
            self.skip_convs.append(nn.Conv2d(in_channels=condition.model_total_out_dim, out_channels=condition.skip_dim, kernel_size=(1, 1)))


        self.conv1 = nn.Conv1d(in_channels=condition.stcmformer_out, out_channels=condition.c_out, kernel_size=1, bias=True)
        self.conv2 = nn.Conv1d(in_channels=condition.midd, out_channels=condition.c_out, kernel_size=1, bias=True)

    def forward(self, batch_x, batch_x_mark, batch_y, batch_y_mark, stst_input):
        stst_input = stst_input.transpose(1, 3)
        dis_sel = np.load(os.path.join(self.condition.root_path, self.condition.dis_sel))
        dis_sel = torch.tensor(dis_sel).to(self.device).float()
        sid_sel = np.load(os.path.join(self.condition.root_path, self.condition.sid_sel))
        sid_sel = torch.tensor(sid_sel).to(self.device).float()
        dtw_sel = np.load(os.path.join(self.condition.root_path, self.condition.dtw_sel))
        dtw_sel = torch.tensor(dtw_sel).to(self.device).float()

        skip_connection = 0
        for i in range(self.condition.blocks):
            ltst_output = self.stautoformer[i](batch_x, batch_x_mark, batch_y, batch_y_mark, af_assist)##(b,p,d)

            mgstc_output = self.mgstc[i](stst_input)
            mgstc_output = mgstc_output.transpose(1, 3)


            scgat_output = self.scgat[i](mgstc_output)
            stst_output = scgat_output + mgstc_output
            stst_output = stst_output[:, :, self.condition.target-1,:]

            adgfm_output = self.adgfm[i](ltst_output, stst_output)


            #dim adjust
            # adgfm_output = adgfm_output.unsqueeze(dim=3)#(16,24,1,1)
            # adgfm_output = adgfm_output.transpose(1, 3)#(16,1,1,24)

            #skip connection
            #s = self.skip_convs[i](adgfm_output)#1->2   #(16,2,1,24)
            # s = adgfm_output

            # if skip_connection.nelement() == 0:
            #     skip_connection = adgfm_output
            # else:
            #     skip_connection = torch.cat([skip_connection, adgfm_output], dim=1)

            # try:
            #     skip_connection = skip_connection[:, :, :, -adgfm_output.size(2):]
            # except:
            #     skip_connection = 0


            res = adgfm_output + skip_connection
            #skip_connection =  ltst_output +   stst_output+skip_connection

        # #model_total_output = self.end_conv_1(skip_connection)
        # model_total_output = skip_connection
        # # x = F.relu(skip_connection)
        # # x = F.relu(self.end_conv_1(x))#4->16 #(16,16,1,24)#2->1 #(16,1,1,24)
        # # model_total_output = self.end_conv_2(x)#16->1  #(16,1,1,24)
        #
        # #dim adjust
        # model_total_output = model_total_output.transpose(1, 3)#(16,24,1,1)
        # #model_total_output = torch.squeeze(model_total_output, dim=3)
        # model_total_output = model_total_output.squeeze(dim=3)#(16,24,1)
        result = res

        return result

    def _acquire_device(self):
        if self.condition.use_gpu:
            os.environ["CUDA_VISIBLE_DEVICES"] = str(self.condition.gpu) if not self.condition.use_multi_gpu else self.condition.devices
            device = torch.device('cuda:{}'.format(self.condition.gpu))
        else:
            device = torch.device('cpu')
        return device

